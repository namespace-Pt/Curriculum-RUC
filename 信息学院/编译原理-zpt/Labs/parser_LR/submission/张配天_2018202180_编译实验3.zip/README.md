.
│  closure.cpp                          // 源代码
│  closure.h
│  grammer.cpp
│  grammer.h
│  grammers.cpp
│  grammers.h
│  item.cpp
│  item.h
│  lexer.cpp
│  main.cpp
│  main.exe
│  parser.cpp
│  parser.h
│  README.md
│  symbol.cpp
│  symbol.h
│
├─data                                  // 数据
│      grammers.txt
│      KeyWords.txt
│      lex_result.out
│      Operators.txt
│      Separators.txt
│      test.in
│
└─docs                                  // 实验报告
        report.pdf